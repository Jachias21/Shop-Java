package main;

	public interface Logable {
	    boolean login(int user, String password);
	}
